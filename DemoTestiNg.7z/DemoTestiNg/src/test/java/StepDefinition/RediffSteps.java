package StepDefinition;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import hooks.Hooks;
import io.cucumber.java.en.*;

public class RediffSteps {

    WebDriver driver = Hooks.driver;
    WebDriverWait wait;

    @Given("user opens the browser")
    public void user_opens_browser() {
        driver = Hooks.driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @When("user opens Rediff website")
    public void user_opens_rediff_website() {
        driver.get("https://www.rediff.com/");
    }

    @And("user clicks on Create Account")
    public void user_clicks_on_create_account() {
        driver.findElement(By.linkText("Create Account")).click();
    }

    @Then("user should see Create Rediffmail Account page")
    public void user_should_see_create_rediffmail_account_page() {
        Assert.assertEquals(
            driver.getTitle(),
            "Rediffmail Free Unlimited Storage"
        );
    }

    @Then("user enters name {string}")
    public void user_enters_name(String name) {
        WebElement nameField = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[contains(@name,'name')]")
            )
        );
        nameField.clear();
        nameField.sendKeys(name);
    }

    @Then("user enters email {string}")
    public void user_enters_email(String email) {
        WebElement emailField = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[contains(@name,'login')]")
            )
        );
        emailField.clear();
        emailField.sendKeys(email);
    }
}
