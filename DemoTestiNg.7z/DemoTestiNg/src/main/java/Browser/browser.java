package Browser;
//
//import java.time.Duration;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import com.aventstack.extentreports.ExtentReports;
//import com.aventstack.extentreports.ExtentTest;
//import com.aventstack.extentreports.reporter.ExtentSparkReporter;
//
//public class browser {
//	public static WebDriver driver; // Declared object globally
//	public static WebDriverWait wait;
//	public static Actions action;
//	public static Select select;
//
//	/*
//	 * Open the browser based on the choice
//	 */
//	
//	static ExtentReports extent=new ExtentReports();
//	static ExtentSparkReporter reporter=new ExtentSparkReporter(
//			System.getProperty("user.dir")+"//target//Reports//extentReport1.html");
//	static ExtentTest logger1;
//	public static void openBrowser() throws Exception {
//		extent.attachReporter(reporter);
//		try {
//			String choice = utility.properties("browser"); // Chrome
//			if (choice.equalsIgnoreCase("Chrome"))
//				driver = new ChromeDriver();
//			else if (choice.equalsIgnoreCase("Edge"))
//				driver = new EdgeDriver();
//			else if (choice.equalsIgnoreCase("Firefox")) {
//				System.out.print("If block working");
//				driver = new FirefoxDriver();
//			}
//		} catch (Exception e) {
//			// e.printStackTrace();
//			System.out.println("Browser - openBrowser" + e);
//		}
//	}
//
//	/*
//	 * Pauses the URL of the application
//	 */
//	public static void navigate(String title) throws Exception {
//		try {
//			driver.get(utility.properties("url")); // https://www.rediff.com
//			driver.manage().window().maximize();
//			action = new Actions(driver);
//			wait = new WebDriverWait(driver, Duration.ofSeconds(30)); //explicit wait
//			wait.until(ExpectedConditions.titleIs(title));
//			extent.attachReporter(reporter);
//		    logger1 = extent.createTest("Open Test");
//		    logger1.log(Status.INFO, "Open the Application");
//		    try {
//		       driver = new ChromeDriver();
//		      driver.get("https://www.google.com/");
//		      //DemoLog.sample(1);
//		      driver.manage().window().maximize();
//		      Thread.sleep(2000);  
//		      logger1.log(Status.PASS, "Application opened");
//		    }
//		    catch( Exception e)
//		    {
//		      //DemoLog.sample(3);
//		      logger1.log(Status.FAIL, "Failed Logout");
//		    }
//		    extent.flush();
//		} catch (Exception e) {
//			System.out.println("Browser - navigate" + e);
//		}
//	}
//	/*
//	 * Closes the Browser
//	 */
//	public static void closeBrowser() {
//		try {
//			driver.quit();
//		} catch (Exception e) {
//			System.out.println("Browser - closeBrowser");
//		}
//	}
//	
//	public static void main(String args[]) throws Exception{
//		browser.openBrowser();
//		browser.navigate("https://www.rediff.com");
//		browser.closeBrowser();
//	}
//}

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class browser {
    public static WebDriver driver;

    public static void openBrowser() throws Exception {
        String choice = utility.properties("browser");

        if (choice.equalsIgnoreCase("Chrome"))
            driver = new ChromeDriver();
        else if (choice.equalsIgnoreCase("Edge"))
            driver = new EdgeDriver();
        else if (choice.equalsIgnoreCase("Firefox"))
            driver = new FirefoxDriver();
    }

    public static void navigateToApp() throws Exception {
        driver.get(utility.properties("url"));
        driver.manage().window().maximize();
    }

    public static void closeBrowser() {
        driver.quit();
    }
}
